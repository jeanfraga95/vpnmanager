#!/bin/bash
#============================================================
#  VPNManager Lite - Menu Principal
#============================================================
INSTALL_DIR="/etc/VPNManager"

source "$INSTALL_DIR/modules/common.sh"
source "$INSTALL_DIR/modules/ssh_users.sh"
source "$INSTALL_DIR/modules/xray.sh"
source "$INSTALL_DIR/modules/v2ray.sh"
source "$INSTALL_DIR/modules/online_users.sh"
source "$INSTALL_DIR/modules/slowdns.sh"
source "$INSTALL_DIR/modules/badvpn.sh"
source "$INSTALL_DIR/modules/telegram_bot.sh"
source "$INSTALL_DIR/modules/system_info.sh"

for fn in ssh_users_menu xray_menu xray_is_installed \
          v2ray_menu v2ray_is_installed \
          online_users_menu slowdns_menu badvpn_menu telegram_bot_menu \
          system_info_menu; do
    if ! declare -F "$fn" >/dev/null 2>&1; then
        echo -e "\033[1;31m[ERRO]\033[0m Função '$fn' não encontrada."
        echo "Reinstale o painel: ./install.sh"
        exit 1
    fi
done

require_root

draw_header(){
    local ip total_users xray_st v2ray_st bot_st
    ip=$(get_ip)
    total_users=$(awk -F: '$3>=1000 && $7=="/bin/false"' /etc/passwd | wc -l)

    # conta online (uma única chamada a ps, em vez de uma por usuário)
    local online=0
    local vpn_users; mapfile -t vpn_users < <(awk -F: '$3>=1000 && $7=="/bin/false"{print $1}' /etc/passwd)
    if [[ ${#vpn_users[@]} -gt 0 ]]; then
        local active_users; active_users=$'\n'"$(ps -eo user= | sort -u)"$'\n'
        for u in "${vpn_users[@]}"; do
            [[ "$active_users" == *$'\n'"$u"$'\n'* ]] && (( online++ ))
        done
    fi

    if xray_is_installed && systemctl is-active --quiet xray; then
        xray_st="${C_GREEN}ATIVO${C_NC}"
    elif xray_is_installed; then
        xray_st="${C_RED}PARADO${C_NC}"
    else
        xray_st="${C_YELLOW}não inst.${C_NC}"
    fi

    if v2ray_is_installed && systemctl is-active --quiet v2ray; then
        v2ray_st="${C_GREEN}ATIVO${C_NC}"
    elif v2ray_is_installed; then
        v2ray_st="${C_RED}PARADO${C_NC}"
    else
        v2ray_st="${C_YELLOW}não inst.${C_NC}"
    fi

    if bot_is_configured && bot_is_active; then
        bot_st="${C_GREEN}ATIVO${C_NC}"
    elif bot_is_configured; then
        bot_st="${C_RED}PARADO${C_NC}"
    else
        bot_st="${C_YELLOW}não conf.${C_NC}"
    fi

    echo -e "${C_CYAN}╔══════════════════════════════════════════════════════════╗${C_NC}"
    echo -e "${C_CYAN}║${C_WHITE}                  V P N M A N A G E R                      ${C_CYAN}║${C_NC}"
    echo -e "${C_CYAN}╠══════════════════════════════════════════════════════════╣${C_NC}"
    printf "${C_CYAN}║${C_NC}  IP: ${C_GREEN}%-18s${C_NC}  Users: ${C_GREEN}%-3s${C_NC} Online: ${C_GREEN}%-3s${C_NC}    ${C_CYAN}║${C_NC}\n" \
        "$ip" "$total_users" "$online"
    printf "${C_CYAN}║${C_NC}  Xray: %-20b  V2Ray: %-18b${C_CYAN}║${C_NC}\n" \
        "$xray_st" "$v2ray_st"
    printf "${C_CYAN}║${C_NC}  Bot Telegram: %-40b${C_CYAN}║${C_NC}\n" "$bot_st"
    echo -e "${C_CYAN}╚══════════════════════════════════════════════════════════╝${C_NC}"
}

_xray_install_prompt(){
    clear
    echo -e "${C_CYAN}== Xray — não instalado ==${C_NC}"
    echo
    echo " O Xray suporta VLESS + XHTTP / HTTPUpgrade / gRPC + TLS"
    echo
    read -p " Instalar Xray agora? [s/N]: " resp
    [[ "$resp" =~ ^[sS]$ ]] && xray_menu
}

main_menu(){
    while true; do
        clear
        draw_header
        echo
        echo "  1) Usuários SSH"
        echo "  2) Usuários Online"
        echo
        if xray_is_installed; then
            echo "  3) Xray  (VLESS · XHTTP · HTTPUpgrade · gRPC)"
        else
            echo -e "  3) Xray  ${C_YELLOW}(não instalado)${C_NC}"
        fi
        if v2ray_is_installed; then
            echo "  4) V2Ray (VMess · TCP · WS · mKCP)"
        else
            echo -e "  4) V2Ray ${C_YELLOW}(não instalado)${C_NC}"
        fi
        echo
        if slowdns_is_installed; then
            echo -e "  5) SlowDNS  ${C_GREEN}(ativo)${C_NC}"
        else
            echo "  5) SlowDNS  (DNS tunnel)"
        fi
        if badvpn_is_installed; then
            echo -e "  6) BadVPN   ${C_GREEN}(ativo)${C_NC}"
        else
            echo "  6) BadVPN   (UDPGW — streaming/jogos)"
        fi
        if bot_is_configured; then
            echo -e "  7) Bot Telegram  ${C_GREEN}(configurado)${C_NC}"
        else
            echo "  7) Bot Telegram"
        fi
        echo
        echo "  8) Informações do Sistema (CPU, RAM, portas)"
        echo
        echo "  0) Sair"
        echo
        echo -e "${C_CYAN}──────────────────────────────────────────────────────────${C_NC}"
        read -p " Escolha: " opt
        case $opt in
            1) ssh_users_menu ;;
            2) online_users_menu ;;
            3) xray_is_installed && xray_menu || _xray_install_prompt ;;
            4) v2ray_menu ;;
            5) slowdns_menu ;;
            6) badvpn_menu ;;
            7) telegram_bot_menu ;;
            8) system_info_menu ;;
            0) clear; exit 0 ;;
            *) fail "Opção inválida."; sleep 1 ;;
        esac
    done
}

main_menu

#!/bin/bash
#============================================================
# telegram_bot.sh - Bot Telegram para gerenciamento remoto
#
# Comandos do bot:
#   /criar <user> <senha> <dias> <limite> — cria usuário SSH
#   /teste <user> <senha> <minutos>       — cria usuário teste
#   /onlines                              — usuários online
#   /listar                               — todos os usuários
#   /remover <user>                       — remove usuário
#   /backup                               — gera e envia backup
#   /restaurar                            — instruções de restore
#   /status                               — status dos serviços
#   /ajuda                                — lista comandos
#============================================================
source "$INSTALL_DIR/modules/common.sh"

BOT_CONF="$INSTALL_DIR/conf/telegram_bot.conf"
BOT_SERVICE="/etc/systemd/system/vpnbot.service"
BOT_SCRIPT="/usr/local/bin/vpnbot_worker.sh"
BOT_OFFSET_FILE="/tmp/vpnbot_offset"
PM_DB="/root/pm_users.db"
BACKUP_DIR="/root/vpnmanager_backups"

# ── Helpers ──────────────────────────────────────────────────

bot_is_configured(){
    [[ -f "$BOT_CONF" ]] && source "$BOT_CONF" 2>/dev/null
    [[ -n "$BOT_TOKEN" && -n "$BOT_CHAT_ID" ]]
}

bot_is_active(){
    systemctl is-active --quiet vpnbot 2>/dev/null
}

_bot_load_conf(){
    [[ -f "$BOT_CONF" ]] && source "$BOT_CONF" 2>/dev/null
}

# ── API Telegram via curl ─────────────────────────────────────

_tg_send(){
    local token="$1" chat_id="$2" text="$3"
    curl -s -X POST "https://api.telegram.org/bot${token}/sendMessage" \
        -d "chat_id=${chat_id}" \
        -d "parse_mode=Markdown" \
        --data-urlencode "text=${text}" \
        > /dev/null 2>&1
}

_tg_send_file(){
    local token="$1" chat_id="$2" filepath="$3" caption="$4"
    curl -s -X POST "https://api.telegram.org/bot${token}/sendDocument" \
        -F "chat_id=${chat_id}" \
        -F "document=@${filepath}" \
        -F "caption=${caption}" \
        > /dev/null 2>&1
}

_tg_get_updates(){
    local token="$1" offset="$2"
    curl -s "https://api.telegram.org/bot${token}/getUpdates?offset=${offset}&timeout=30"
}

# ── Geração do worker (script que roda como serviço) ──────────

_write_bot_worker(){
    local token="$1" chat_id="$2"

    cat > "$BOT_SCRIPT" << WORKEREOF
#!/bin/bash
#============================================================
# vpnbot_worker.sh — worker do bot Telegram (gerado automaticamente)
#============================================================
INSTALL_DIR="${INSTALL_DIR}"
BOT_TOKEN="${token}"
BOT_CHAT_ID="${chat_id}"
PM_DB="/root/pm_users.db"
BACKUP_DIR="${BACKUP_DIR}"
OFFSET_FILE="${BOT_OFFSET_FILE}"

source "\$INSTALL_DIR/modules/common.sh"
source "\$INSTALL_DIR/modules/ssh_users.sh"

# ── Utilitários ───────────────────────────────────────────────

tg_reply(){
    curl -s -X POST "https://api.telegram.org/bot\${BOT_TOKEN}/sendMessage" \\
        -d "chat_id=\${BOT_CHAT_ID}" \\
        -d "parse_mode=Markdown" \\
        --data-urlencode "text=\$1" > /dev/null 2>&1
}

tg_send_file(){
    curl -s -X POST "https://api.telegram.org/bot\${BOT_TOKEN}/sendDocument" \\
        -F "chat_id=\${BOT_CHAT_ID}" \\
        -F "document=@\$1" \\
        -F "caption=\$2" > /dev/null 2>&1
}

count_procs(){ ps -u "\$1" -o pid= 2>/dev/null | wc -l | tr -d ' '; }

# ── Funções de resposta ───────────────────────────────────────

cmd_ajuda(){
    tg_reply "🤖 *VPNManager Bot*

*/criar* \`<user> <senha> <dias> <limite>\`
→ Cria usuário SSH

*/teste* \`<user> <senha> <minutos>\`
→ Cria usuário teste temporário

*/remover* \`<user>\`
→ Remove usuário SSH

*/listar*
→ Lista todos os usuários

*/onlines*
→ Usuários conectados agora

*/status*
→ Status dos serviços (Xray, V2Ray, SSH)

*/backup*
→ Gera e envia backup completo

*/ajuda*
→ Esta mensagem"
}

cmd_criar(){
    local user="\$1" pass="\$2" dias="\$3" limite="\$4"
    [[ -z "\$user" || -z "\$pass" || -z "\$dias" ]] && {
        tg_reply "❌ Uso: /criar <user> <senha> <dias> <limite>"; return; }
    [[ ! "\$dias" =~ ^[0-9]+\$ ]] && {
        tg_reply "❌ Dias deve ser número."; return; }
    limite="\${limite:-0}"

    local result; result=\$(ssh_create_api "\$user" "\$pass" "\$dias" "\$limite" 2>&1)
    if [[ "\$result" == "CRIADOCOMSUCESSO" ]]; then
        local ip; ip=\$(curl -s --max-time 5 ifconfig.me 2>/dev/null || echo "IP")
        local exp; exp=\$(date "+%d/%m/%Y" -d "+\$((\$dias+1)) days")
        tg_reply "✅ *Usuário criado!*

👤 Usuário : \`\$user\`
🔑 Senha   : \`\$pass\`
📅 Expira  : \$exp
🔗 Limite  : \$([\$limite -eq 0] && echo 'ilimitado' || echo \"\$limite conexões\")
🌐 IP VPS  : \`\$ip\`"
    else
        tg_reply "❌ Erro ao criar usuário: \$result"
    fi
}

cmd_teste(){
    local user="\$1" pass="\$2" minutos="\$3"
    [[ -z "\$user" || -z "\$pass" || -z "\$minutos" ]] && {
        tg_reply "❌ Uso: /teste <user> <senha> <minutos>"; return; }
    [[ ! "\$minutos" =~ ^[0-9]+\$ ]] && {
        tg_reply "❌ Minutos deve ser número."; return; }

    local result; result=\$(ssh_create_api "\$user" "\$pass" "1" "1" 2>&1)
    if [[ "\$result" == "CRIADOCOMSUCESSO" ]]; then
        local ip; ip=\$(curl -s --max-time 5 ifconfig.me 2>/dev/null || echo "IP")
        tg_reply "✅ *Teste criado!*

👤 Usuário : \`\$user\`
🔑 Senha   : \`\$pass\`
⏱ Expira  : \${minutos} minuto(s)
🌐 IP VPS  : \`\$ip\`"
        # remove após X minutos
        nohup bash -c "sleep \$((\$minutos * 60)) && ssh_remove_api '\$user'" >/dev/null 2>&1 &
    else
        tg_reply "❌ Erro ao criar teste: \$result"
    fi
}

cmd_remover(){
    local user="\$1"
    [[ -z "\$user" ]] && { tg_reply "❌ Uso: /remover <user>"; return; }
    local result; result=\$(ssh_remove_api "\$user" 2>&1)
    if [[ "\$result" == "REMOVIDOCOMSUCESSO" ]]; then
        tg_reply "✅ Usuário *\$user* removido."
    else
        tg_reply "❌ Erro: \$result"
    fi
}

cmd_listar(){
    local lista="" total=0
    while IFS=: read -r u _ uid _ _ _ shell; do
        [[ "\$uid" -lt 1000 || "\$shell" != "/bin/false" ]] && continue
        (( total++ ))
        local exp; exp=\$(chage -l "\$u" 2>/dev/null \
            | grep "Account expires" | cut -d: -f2 | xargs)
        [[ "\$exp" == "never" || -z "\$exp" ]] && exp="nunca"
        local limit; limit=\$(grep "^\$u " "\$PM_DB" 2>/dev/null | awk '{print \$2}')
        [[ -z "\$limit" || "\$limit" == "0" ]] && limit="∞"
        lista+="\n👤 \`\$u\` | expira: \$exp | limite: \$limit"
    done < /etc/passwd
    [[ \$total -eq 0 ]] && { tg_reply "📋 Nenhum usuário cadastrado."; return; }
    tg_reply "📋 *Usuários cadastrados (\$total)*\${lista}"
}

cmd_onlines(){
    local lista="" total=0
    while IFS=: read -r u _ uid _ _ _ shell; do
        [[ "\$uid" -lt 1000 || "\$shell" != "/bin/false" ]] && continue
        local procs; procs=\$(count_procs "\$u")
        [[ "\$procs" -eq 0 ]] && continue
        (( total++ ))
        lista+="\n🟢 \`\$u\` — \$procs conexão(ões)"
    done < /etc/passwd
    if [[ \$total -eq 0 ]]; then
        tg_reply "📡 Nenhum usuário online agora."
    else
        tg_reply "📡 *Online agora (\$total)*\${lista}"
    fi
}

cmd_status(){
    local msg="⚙️ *Status dos Serviços*\n"
    for svc in ssh xray v2ray slowdns badvpn; do
        if systemctl is-active --quiet "\$svc" 2>/dev/null; then
            msg+="\n✅ \$svc — ATIVO"
        elif systemctl list-units --all 2>/dev/null | grep -q "\$svc"; then
            msg+="\n🔴 \$svc — PARADO"
        fi
    done
    local uptime; uptime=\$(uptime -p 2>/dev/null | sed 's/up //')
    local mem; mem=\$(free -m 2>/dev/null | awk '/^Mem/{printf "%dMB/%dMB", \$3, \$2}')
    msg+="\n\n🖥 Uptime : \$uptime"
    msg+="\n💾 Memória: \$mem"
    tg_reply "\$msg"
}

cmd_backup(){
    tg_reply "📦 Gerando backup... aguarde."
    mkdir -p "\$BACKUP_DIR"
    local ts; ts=\$(date +%Y%m%d_%H%M%S)
    local file="\$BACKUP_DIR/vpnbackup_\$ts.tar.gz"

    tar -czf "\$file" \\
        /root/pm_users.db \\
        /etc/SSHPlus/ \\
        /usr/local/etc/xray/config.json \\
        /usr/local/etc/v2ray/config.json \\
        "\$INSTALL_DIR/conf/" \\
        2>/dev/null

    if [[ -f "\$file" ]]; then
        tg_send_file "\$file" "🗂 Backup \$ts"
        tg_reply "✅ Backup enviado: \`vpnbackup_\$ts.tar.gz\`"
    else
        tg_reply "❌ Falha ao gerar backup."
    fi
}

cmd_restaurar(){
    tg_reply "♻️ *Restaurar backup*

Para restaurar, envie o arquivo .tar.gz para o servidor e execute:

\`\`\`
tar -xzf /root/vpnbackup_XXXXXX.tar.gz -C /
systemctl restart xray v2ray ssh
\`\`\`

Os backups ficam em \`${BACKUP_DIR}/\`"
}

# ── Loop principal ────────────────────────────────────────────

OFFSET=0
[[ -f "\$OFFSET_FILE" ]] && OFFSET=\$(cat "\$OFFSET_FILE")

while true; do
    updates=\$(curl -s --max-time 35 \\
        "https://api.telegram.org/bot\${BOT_TOKEN}/getUpdates?offset=\${OFFSET}&timeout=30")

    if [[ -z "\$updates" || "\$updates" == *'"ok":false'* ]]; then
        sleep 5; continue
    fi

    # processa cada update
    while IFS= read -r update; do
        [[ -z "\$update" ]] && continue

        update_id=\$(echo "\$update" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('update_id',''))" 2>/dev/null)
        [[ -z "\$update_id" ]] && continue

        OFFSET=\$(( update_id + 1 ))
        echo "\$OFFSET" > "\$OFFSET_FILE"

        # extrai chat_id e texto
        from_chat=\$(echo "\$update" | python3 -c "
import sys,json
d=json.load(sys.stdin)
msg=d.get('message',{})
print(msg.get('chat',{}).get('id',''))
" 2>/dev/null)

        # só responde ao chat_id autorizado
        [[ "\$from_chat" != "\$BOT_CHAT_ID" ]] && continue

        text=\$(echo "\$update" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(d.get('message',{}).get('text',''))
" 2>/dev/null)

        [[ -z "\$text" ]] && continue

        cmd=\$(echo "\$text" | awk '{print \$1}' | tr '[:upper:]' '[:lower:]')
        args=(\$(echo "\$text" | awk '{for(i=2;i<=NF;i++) printf \$i" "; print ""}'))

        case "\$cmd" in
            /criar)     cmd_criar "\${args[0]}" "\${args[1]}" "\${args[2]}" "\${args[3]}" ;;
            /teste)     cmd_teste "\${args[0]}" "\${args[1]}" "\${args[2]}" ;;
            /remover)   cmd_remover "\${args[0]}" ;;
            /listar)    cmd_listar ;;
            /onlines)   cmd_onlines ;;
            /status)    cmd_status ;;
            /backup)    cmd_backup ;;
            /restaurar) cmd_restaurar ;;
            /ajuda|/start|/help) cmd_ajuda ;;
        esac

    done < <(echo "\$updates" | python3 -c "
import sys,json
data=json.load(sys.stdin)
for r in data.get('result',[]):
    print(json.dumps(r))
" 2>/dev/null)

done
WORKEREOF

    chmod +x "$BOT_SCRIPT"
}

# ── Serviço systemd ───────────────────────────────────────────

_write_bot_service(){
    cat > "$BOT_SERVICE" << SVC
[Unit]
Description=VPNManager Telegram Bot
After=network.target

[Service]
User=root
ExecStart=/bin/bash ${BOT_SCRIPT}
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SVC
    systemctl daemon-reload
}

# ── Instalação principal ──────────────────────────────────────

telegram_bot_install(){
    clear
    echo -e "${C_CYAN}== Configurar Bot Telegram ==${C_NC}"
    echo
    echo " Como obter o token:"
    echo "  1. Abra o Telegram e fale com @BotFather"
    echo "  2. Envie /newbot e siga as instruções"
    echo "  3. Copie o token gerado (ex: 123456:ABC-DEF...)"
    echo
    read -p " Token do bot: " token
    [[ -z "$token" ]] && { fail "Token não pode ser vazio."; pause; return; }

    echo
    echo " Como obter seu Chat ID:"
    echo "  1. Fale com @userinfobot no Telegram"
    echo "  2. Ele responde com seu ID numérico"
    echo "  Ou fale com o bot e acesse:"
    echo "  https://api.telegram.org/bot${token}/getUpdates"
    echo
    read -p " Seu Chat ID (numérico): " chat_id
    [[ -z "$chat_id" ]] && { fail "Chat ID não pode ser vazio."; pause; return; }

    # testa o token
    msg "Testando conexão com a API Telegram..."
    local test_result
    test_result=$(curl -s --max-time 10 \
        "https://api.telegram.org/bot${token}/getMe")
    if echo "$test_result" | grep -q '"ok":true'; then
        local bot_name
        bot_name=$(echo "$test_result" | python3 -c \
            "import sys,json; d=json.load(sys.stdin); \
             print(d['result'].get('username','?'))" 2>/dev/null)
        ok "Bot encontrado: @${bot_name}"
    else
        fail "Token inválido ou sem conexão com a API Telegram."
        echo "$test_result"
        pause; return
    fi

    # salva config
    mkdir -p "$(dirname "$BOT_CONF")"
    cat > "$BOT_CONF" << CONF
BOT_TOKEN="$token"
BOT_CHAT_ID="$chat_id"
CONF
    chmod 600 "$BOT_CONF"

    mkdir -p "$BACKUP_DIR"
    _write_bot_worker "$token" "$chat_id"
    _write_bot_service

    systemctl enable vpnbot 2>/dev/null
    systemctl restart vpnbot
    sleep 3

    if bot_is_active; then
        ok "Bot ativo e aguardando mensagens."
        # envia mensagem de teste
        _tg_send "$token" "$chat_id" \
            "✅ *VPNManager Bot conectado!*

Envie /ajuda para ver os comandos disponíveis."
        ok "Mensagem de boas-vindas enviada."
    else
        fail "Bot não iniciou."
        journalctl -u vpnbot -n 15 --no-pager 2>/dev/null
        pause; return
    fi

    echo
    echo -e "${C_CYAN}════════════════════════════════════════════════════${C_NC}"
    echo -e "${C_WHITE} BOT CONFIGURADO${C_NC}"
    echo -e "${C_CYAN}════════════════════════════════════════════════════${C_NC}"
    echo " Token   : ${token:0:20}..."
    echo " Chat ID : $chat_id"
    echo
    echo " Comandos disponíveis no Telegram:"
    echo "  /criar  /teste  /remover  /listar"
    echo "  /onlines  /status  /backup  /ajuda"
    echo -e "${C_CYAN}════════════════════════════════════════════════════${C_NC}"
    pause
}

# ── Desinstalar ───────────────────────────────────────────────

telegram_bot_uninstall(){
    clear
    echo -e "${C_RED}== Remover Bot Telegram ==${C_NC}"
    read -p "Confirma remoção? [s/N]: " conf
    [[ "$conf" =~ ^[sS]$ ]] || return
    systemctl disable --now vpnbot 2>/dev/null
    rm -f "$BOT_SERVICE" "$BOT_SCRIPT" "$BOT_CONF" "$BOT_OFFSET_FILE"
    systemctl daemon-reload
    ok "Bot removido."
    pause
}

# ── Menu ──────────────────────────────────────────────────────

telegram_bot_menu(){
    while true; do
        clear
        echo -e "${C_CYAN}╔══════════════════════════════════════════════════════════╗${C_NC}"
        echo -e "${C_CYAN}║${C_WHITE}                    BOT TELEGRAM                           ${C_CYAN}║${C_NC}"
        echo -e "${C_CYAN}╚══════════════════════════════════════════════════════════╝${C_NC}"
        echo

        _bot_load_conf
        if bot_is_configured; then
            local badge
            bot_is_active \
                && badge="${C_GREEN}● ATIVO${C_NC}" \
                || badge="${C_RED}● PARADO${C_NC}"
            echo -e " Status  : $badge"
            echo -e " Chat ID : ${C_GREEN}${BOT_CHAT_ID}${C_NC}"
            echo -e " Token   : ${C_GREEN}${BOT_TOKEN:0:20}...${C_NC}"
            echo
            echo " Comandos no Telegram:"
            echo -e "  ${C_YELLOW}/criar /teste /remover /listar${C_NC}"
            echo -e "  ${C_YELLOW}/onlines /status /backup /ajuda${C_NC}"
            echo
            echo "  1) Reiniciar bot"
            echo "  2) Reconfigurar"
            echo "  3) Ver logs"
            echo "  4) Remover bot"
            echo "  0) Voltar"
        else
            echo -e " ${C_YELLOW}Bot não configurado.${C_NC}"
            echo
            echo "  1) Configurar Bot Telegram"
            echo "  0) Voltar"
        fi
        echo
        read -p " Escolha: " op

        if bot_is_configured; then
            case $op in
                1) systemctl restart vpnbot && ok "Reiniciado." || fail "Erro."; sleep 2 ;;
                2) telegram_bot_uninstall; telegram_bot_install ;;
                3)
                    clear
                    echo -e "${C_CYAN}== Logs do Bot ==${C_NC}"
                    journalctl -u vpnbot -n 40 --no-pager 2>/dev/null
                    pause
                    ;;
                4) telegram_bot_uninstall ;;
                0) break ;;
                *) fail "Opção inválida."; sleep 1 ;;
            esac
        else
            case $op in
                1) telegram_bot_install ;;
                0) break ;;
                *) fail "Opção inválida."; sleep 1 ;;
            esac
        fi
    done
}

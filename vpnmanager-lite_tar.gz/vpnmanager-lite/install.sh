#!/bin/bash
#============================================================
#  VPNManager Lite - Instalador
#============================================================
set -e

INSTALL_DIR="/etc/VPNManager"
BIN_LINK="/usr/local/bin/menuvpn"

G="\033[1;32m"; R="\033[1;31m"; C="\033[1;36m"; NC="\033[0m"
ok()  { echo -e "${G}[OK]${NC} $1"; }
fail(){ echo -e "${R}[ERRO]${NC} $1"; exit 1; }
msg() { echo -e "${C}[*]${NC} $1"; }

[[ "$EUID" -ne 0 ]] && fail "Execute como root."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

msg "Criando estrutura em $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR/modules" "$INSTALL_DIR/conf"

msg "Copiando módulos..."
cp "$SCRIPT_DIR/menu.sh"                         "$INSTALL_DIR/menu.sh"
cp "$SCRIPT_DIR/modules/common.sh"               "$INSTALL_DIR/modules/common.sh"
cp "$SCRIPT_DIR/modules/ssh_users.sh"            "$INSTALL_DIR/modules/ssh_users.sh"
cp "$SCRIPT_DIR/modules/xray.sh"                 "$INSTALL_DIR/modules/xray.sh"
cp "$SCRIPT_DIR/modules/v2ray.sh"                "$INSTALL_DIR/modules/v2ray.sh"
cp "$SCRIPT_DIR/modules/online_users.sh"         "$INSTALL_DIR/modules/online_users.sh"
cp "$SCRIPT_DIR/modules/slowdns.sh"              "$INSTALL_DIR/modules/slowdns.sh"
cp "$SCRIPT_DIR/modules/badvpn.sh"               "$INSTALL_DIR/modules/badvpn.sh"
cp "$SCRIPT_DIR/modules/telegram_bot.sh"         "$INSTALL_DIR/modules/telegram_bot.sh"
cp "$SCRIPT_DIR/modules/system_info.sh"          "$INSTALL_DIR/modules/system_info.sh"

chmod +x "$INSTALL_DIR/menu.sh"
chmod +x "$INSTALL_DIR/modules/"*.sh

msg "Criando atalho '$BIN_LINK'..."
ln -sf "$INSTALL_DIR/menu.sh" "$BIN_LINK"

# Diretórios exigidos pela integração com pmaster_agent
mkdir -p /etc/SSHPlus/senha /etc/PanelMaster /etc/usuarios
touch /root/pm_users.db 2>/dev/null || true
groupadd pmg_vpn 2>/dev/null || true

ok "Instalação concluída!"
echo
echo -e "  Execute: ${G}menuvpn${NC}"
